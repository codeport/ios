//
//  UAGithubSimpleJSONParser.h
//  UAGithubEngine
//
//  Created by Owain Hunt on 02/08/2010.
//  Copyright 2010 Owain R Hunt. All rights reserved.
//

#import <Foundation/Foundation.h>


#import "UAGithubJSONParser.h"

@interface UAGithubSimpleJSONParser : UAGithubJSONParser {

}

@end
