//
//  UAGithubEngineConstants.m
//  IssuesHub
//
//  Created by Owain Hunt on 11/11/2010.
//  Copyright 2010 Owain R Hunt. All rights reserved.
//

#import "UAGithubEngineConstants.h"


NSString * const UAGithubAPILimitReached = @"UAGithubAPILimitReached";


