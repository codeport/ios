//
//  main.m
//  UAGithubEngine
//
//  Created by Owain Hunt on 02/04/2010.
//  Copyright 2010 Owain R Hunt. All rights reserved.
//

#import <Cocoa/Cocoa.h>


int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
